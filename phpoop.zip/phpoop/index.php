<?php
 require_once('classes/database.php');
 $con = new database();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logged In</title>
</head>dsadsa
<body>
    <h2>Hello Beneboyyyy</h2>
    
</body>
</html>